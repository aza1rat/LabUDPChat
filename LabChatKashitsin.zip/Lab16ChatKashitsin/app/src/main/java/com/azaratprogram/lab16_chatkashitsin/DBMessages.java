package com.azaratprogram.lab16_chatkashitsin;

public final class DBMessages {
    static DBChat history;
    static DBSettings settings;
}
