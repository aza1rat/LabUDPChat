package com.azaratprogram.lab16_chatkashitsin;

public class Settings {
    public  String ipSend;
    public  String portReceive;
    public  String portSend;
    public  String name;
}
